package com.mea.contentmanagement.mapper;

import com.mea.contentmanagement.domain.Control;
import com.mea.contentmanagement.domain.Page;
import com.mea.contentmanagement.model.Task;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import javax.annotation.processing.Generated;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import org.springframework.stereotype.Component;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2023-10-10T17:24:28+0000",
    comments = "version: 1.5.5.Final, compiler: Eclipse JDT (IDE) 3.34.0.v20230523-1233, environment: Java 17.0.8 (Eclipse Adoptium)"
)
@Component
public class ContentManagementMapperImpl implements ContentManagementMapper {

    private final DatatypeFactory datatypeFactory;

    public ContentManagementMapperImpl() {
        try {
            datatypeFactory = DatatypeFactory.newInstance();
        }
        catch ( DatatypeConfigurationException ex ) {
            throw new RuntimeException( ex );
        }
    }

    @Override
    public com.mea.contentmanagement.model.Page mapPageToPageModel(Page pages) {
        if ( pages == null ) {
            return null;
        }

        com.mea.contentmanagement.model.Page page = new com.mea.contentmanagement.model.Page();

        page.setPageId( pages.getPageId() );
        page.setProjectId( pages.getProjectId() );
        page.setPageCode( pages.getPageCode() );
        page.setPageName( pages.getPageName() );
        page.setActive( pages.isActive() );
        page.setCreatedBy( pages.getCreatedBy() );
        page.setUpdatedBy( pages.getUpdatedBy() );
        page.setCreatedDatetime( pages.getCreatedDatetime() );
        page.setUpdatedDatetime( pages.getUpdatedDatetime() );
        page.setStatus( pages.getStatus() );
        page.setControls( mapControlToControlModel( pages.getControls() ) );

        return page;
    }

    @Override
    public List<Task> mapTaskToTaskModal(List<com.mea.contentmanagement.domain.Task> tasksList) {
        if ( tasksList == null ) {
            return null;
        }

        List<Task> list = new ArrayList<Task>( tasksList.size() );
        for ( com.mea.contentmanagement.domain.Task task : tasksList ) {
            list.add( mapTaskToTaskModel( task ) );
        }

        return list;
    }

    @Override
    public Task mapTaskToTaskModel(com.mea.contentmanagement.domain.Task task) {
        if ( task == null ) {
            return null;
        }

        Task task1 = new Task();

        task1.setCreatedDatetime( xmlGregorianCalendarToString( dateToXmlGregorianCalendar( task.getCreatedDatetime() ), "dd-MMM-yyyy HH:mm:ss" ) );
        task1.setUpdateddateTime( xmlGregorianCalendarToString( dateToXmlGregorianCalendar( task.getUpdateddateTime() ), "dd-MMM-yyyy HH:mm:ss" ) );
        task1.setTaskId( task.getTaskId() );
        task1.setEntityModified( task.getEntityModified() );
        task1.setOperationPerformed( task.getOperationPerformed() );
        task1.setTaskDescription( task.getTaskDescription() );
        task1.setNewObject( task.getNewObject() );
        task1.setOldObject( task.getOldObject() );
        task1.setDecisionType( task.getDecisionType() );
        task1.setDecisiondateTime( xmlGregorianCalendarToString( dateToXmlGregorianCalendar( task.getDecisiondateTime() ), null ) );
        task1.setDecisionComments( task.getDecisionComments() );
        task1.setStatus( task.getStatus() );
        task1.setCreatedBy( task.getCreatedBy() );
        task1.setUpdatedBy( task.getUpdatedBy() );

        return task1;
    }

    @Override
    public List<com.mea.contentmanagement.model.Page> mapPageToPageModelList(List<Page> pagesDomain) {
        if ( pagesDomain == null ) {
            return null;
        }

        List<com.mea.contentmanagement.model.Page> list = new ArrayList<com.mea.contentmanagement.model.Page>( pagesDomain.size() );
        for ( Page page : pagesDomain ) {
            list.add( mapPageToPageModel( page ) );
        }

        return list;
    }

    @Override
    public com.mea.contentmanagement.model.Control mapControlToControlModel(Control controlDomain) {
        if ( controlDomain == null ) {
            return null;
        }

        com.mea.contentmanagement.model.Control control = new com.mea.contentmanagement.model.Control();

        control.setCreatedDateTime( xmlGregorianCalendarToString( dateToXmlGregorianCalendar( controlDomain.getCreatedDateTime() ), "dd-MMM-yyyy HH:mm:ss" ) );
        control.setUpdatedDateTime( xmlGregorianCalendarToString( dateToXmlGregorianCalendar( controlDomain.getUpdatedDateTime() ), "dd-MMM-yyyy HH:mm:ss" ) );
        control.setControlId( controlDomain.getControlId() );
        control.setPageId( controlDomain.getPageId() );
        control.setControlCode( controlDomain.getControlCode() );
        control.setControlType( controlDomain.getControlType() );
        control.setScreen( controlDomain.getScreen() );
        control.setLocaleKey( controlDomain.getLocaleKey() );
        control.setCreatedBy( controlDomain.getCreatedBy() );
        control.setUpdatedBy( controlDomain.getUpdatedBy() );
        control.setStatus( controlDomain.getStatus() );
        control.setLocaleValueEn( controlDomain.getLocaleValueEn() );
        control.setLocaleValueAr( controlDomain.getLocaleValueAr() );
        control.setNewValueEn( controlDomain.getNewValueEn() );
        control.setNewValueAr( controlDomain.getNewValueAr() );

        return control;
    }

    @Override
    public List<com.mea.contentmanagement.model.Control> mapControlToControlModel(List<Control> controlDomain) {
        if ( controlDomain == null ) {
            return null;
        }

        List<com.mea.contentmanagement.model.Control> list = new ArrayList<com.mea.contentmanagement.model.Control>( controlDomain.size() );
        for ( Control control : controlDomain ) {
            list.add( controlToControl( control ) );
        }

        return list;
    }

    @Override
    public Control mapControlToControlDomain(com.mea.contentmanagement.model.Control control) {
        if ( control == null ) {
            return null;
        }

        Control control1 = new Control();

        control1.setControlId( control.getControlId() );
        control1.setPageId( control.getPageId() );
        control1.setControlCode( control.getControlCode() );
        control1.setControlType( control.getControlType() );
        control1.setScreen( control.getScreen() );
        control1.setLocaleKey( control.getLocaleKey() );
        control1.setCreatedBy( control.getCreatedBy() );
        control1.setUpdatedBy( control.getUpdatedBy() );
        control1.setLocaleValueEn( control.getLocaleValueEn() );
        control1.setLocaleValueAr( control.getLocaleValueAr() );
        control1.setNewValueEn( control.getNewValueEn() );
        control1.setNewValueAr( control.getNewValueAr() );
        control1.setStatus( control.getStatus() );

        return control1;
    }

    @Override
    public com.mea.contentmanagement.domain.Task mapTaskTotaskDomain(Task task) {
        if ( task == null ) {
            return null;
        }

        com.mea.contentmanagement.domain.Task task1 = new com.mea.contentmanagement.domain.Task();

        task1.setTaskId( task.getTaskId() );
        task1.setEntityModified( task.getEntityModified() );
        task1.setOperationPerformed( task.getOperationPerformed() );
        task1.setTaskDescription( task.getTaskDescription() );
        task1.setNewObject( task.getNewObject() );
        task1.setOldObject( task.getOldObject() );
        task1.setDecisionType( task.getDecisionType() );
        task1.setDecisionComments( task.getDecisionComments() );
        task1.setStatus( task.getStatus() );
        task1.setCreatedBy( task.getCreatedBy() );
        task1.setUpdatedBy( task.getUpdatedBy() );

        return task1;
    }

    @Override
    public Control mapUpdateControlToControlDomain(com.mea.contentmanagement.model.Control control) {
        if ( control == null ) {
            return null;
        }

        Control control1 = new Control();

        control1.setControlId( control.getControlId() );
        control1.setPageId( control.getPageId() );
        control1.setControlCode( control.getControlCode() );
        control1.setControlType( control.getControlType() );
        control1.setScreen( control.getScreen() );
        control1.setLocaleKey( control.getLocaleKey() );
        control1.setCreatedBy( control.getCreatedBy() );
        control1.setUpdatedBy( control.getUpdatedBy() );
        control1.setLocaleValueEn( control.getLocaleValueEn() );
        control1.setLocaleValueAr( control.getLocaleValueAr() );
        control1.setNewValueEn( control.getNewValueEn() );
        control1.setNewValueAr( control.getNewValueAr() );
        control1.setStatus( control.getStatus() );

        return control1;
    }

    private String xmlGregorianCalendarToString( XMLGregorianCalendar xcal, String dateFormat ) {
        if ( xcal == null ) {
            return null;
        }

        if (dateFormat == null ) {
            return xcal.toString();
        }
        else {
            Date d = xcal.toGregorianCalendar().getTime();
            SimpleDateFormat sdf = new SimpleDateFormat( dateFormat );
            return sdf.format( d );
        }
    }

    private XMLGregorianCalendar dateToXmlGregorianCalendar( Date date ) {
        if ( date == null ) {
            return null;
        }

        GregorianCalendar c = new GregorianCalendar();
        c.setTime( date );
        return datatypeFactory.newXMLGregorianCalendar( c );
    }

    protected com.mea.contentmanagement.model.Control controlToControl(Control control) {
        if ( control == null ) {
            return null;
        }

        com.mea.contentmanagement.model.Control control1 = new com.mea.contentmanagement.model.Control();

        control1.setControlId( control.getControlId() );
        control1.setPageId( control.getPageId() );
        control1.setControlCode( control.getControlCode() );
        control1.setControlType( control.getControlType() );
        control1.setScreen( control.getScreen() );
        control1.setLocaleKey( control.getLocaleKey() );
        control1.setCreatedBy( control.getCreatedBy() );
        control1.setUpdatedBy( control.getUpdatedBy() );
        control1.setCreatedDateTime( xmlGregorianCalendarToString( dateToXmlGregorianCalendar( control.getCreatedDateTime() ), null ) );
        control1.setUpdatedDateTime( xmlGregorianCalendarToString( dateToXmlGregorianCalendar( control.getUpdatedDateTime() ), null ) );
        control1.setStatus( control.getStatus() );
        control1.setLocaleValueEn( control.getLocaleValueEn() );
        control1.setLocaleValueAr( control.getLocaleValueAr() );
        control1.setNewValueEn( control.getNewValueEn() );
        control1.setNewValueAr( control.getNewValueAr() );

        return control1;
    }
}
