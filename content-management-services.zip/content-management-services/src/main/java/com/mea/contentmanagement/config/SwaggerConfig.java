package com.mea.contentmanagement.config;

public class SwaggerConfig {

}
