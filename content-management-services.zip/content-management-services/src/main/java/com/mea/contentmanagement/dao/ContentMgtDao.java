package com.mea.contentmanagement.dao;

import com.mea.contentmanagement.domain.Page;

public interface ContentMgtDao {

	Page getProject();

}
