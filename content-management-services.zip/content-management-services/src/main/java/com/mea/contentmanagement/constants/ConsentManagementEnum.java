package com.mea.contentmanagement.constants;

public enum ConsentManagementEnum {

}
