package com.mea.contentmanagement.response;

import com.mea.contentmanagement.model.Task;

public class TaskDetailedResponse {

	private Task task;

	public Task getTask() {
		return task;
	}

	public void setTask(Task task) {
		this.task = task;
	}
}
