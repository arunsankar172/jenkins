package com.mea.contentmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContentManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
